from Twitter.interfaz import *

if __name__ == '__main__':
    interfazNueva = Interfaz()
