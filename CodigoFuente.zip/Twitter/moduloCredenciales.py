import json
import os
from tkinter import *
from tkinter import ttk
from tkinter.dialog import *

'''Definimos la clase principal de datos: Credenciales'''
class credencialesConexion():

    def __init__(self):
        self.consumerKey = ""
        self.consumerSecret = ""
        self.accessToken = ""
        self.accessTokenSecret = ""
        self.ruta = "Twitter/cred.json"
        self.rutaAux = "cred.json"
        self.cargarArchivo(self.ruta)

    def setConsumerKey(self,codigo):
        self.consumerKey = codigo

    def setConsumerSecret(self,codigo):
        self.consumerSecret = codigo

    def setAccessToken(self,codigo):
        self.accessToken = codigo

    def setAccessTokenSecret(self,codigo):
        self.accessTokenSecret = codigo

    def getConsumerKey(self):
        return self.consumerKey

    def getConsumerSecret(self):
        return self.consumerSecret

    def getAccessToken(self):
        return self.accessToken

    def getAccessTokenSecret(self):
        return self.accessTokenSecret

    def getRuta(self):
        return self.ruta

    def setRuta(self,ruta):
        self.ruta = ruta

    def cargarArchivo(self,ruta):
        try:
            with open(ruta) as f:
                texto = f.read()
                datos = json.loads(texto)
                self.setConsumerKey(datos["consumerKey"])
                self.setConsumerSecret(datos["consumerSecret"])
                self.setAccessToken(datos["accessToken"])
                self.setAccessTokenSecret(datos["accessTokenSecret"])

        except:
            try:
                with open(self.rutaAux) as f:
                    texto = f.read()
                    datos = json.loads(texto)
                    self.setConsumerKey(datos["consumerKey"])
                    self.setConsumerSecret(datos["consumerSecret"])
                    self.setAccessToken(datos["accessToken"])
                    self.setAccessTokenSecret(datos["accessTokenSecret"])

            except:
                print("Fallo en lectura de archivo\n")


    def guardarArchivo(self,ruta):
        texto = ''
        texto += '{'
        texto += '"consumerKey":"'+self.getConsumerKey()+'"'
        texto += ','
        texto += '"consumerSecret":"'+self.getConsumerSecret()+'"'
        texto += ','
        texto += '"accessToken":"'+self.getAccessToken()+'"'
        texto += ','
        texto += '"accessTokenSecret":"'+self.getAccessTokenSecret()+'"'
        texto += '}'
        with open(ruta,"w") as f:
            f.write(texto)

