# -*- coding: utf-8 -*-
import numpy as np
from numpy import linalg as la
import matplotlib.pyplot as plt
import math
import copy
import re
import numpy as np

def punto(x,y,symb):
    plt.plot(x,y,symb)

def texto(x,y,texto):
    plt.text(x,y,texto)

def flecha(dx,dy):
    plt.arrow(0,0,dx,dy)

def mostrarPlot():
    plt.ion()
    plt.xlim([-2,2])
    plt.ylim([-2,2])
    plt.show()

###Procesamiento SVD de Matriz
def singleValueDecomposition(matriz,palabras):

    LA = np.linalg

    a = np.array(matriz)
    #print(a)
    # [[1 3 4]
    #  [5 6 9]
    #  [1 2 3]
    #  [7 6 8]]
    U, s, Vh = LA.svd(a, full_matrices=False)
    assert np.allclose(a, np.dot(U, np.dot(np.diag(s), Vh)))
    print("Autovalores:")
    print(s)
    print("..")
    s[2:] = 0
    new_a = np.dot(U, np.dot(np.diag(s), Vh))
    print(U)
    print(s)
    print(Vh)
    print(new_a)
    # [[ 1.02206755  2.77276308  4.14651336]
    #  [ 4.9803474   6.20236935  8.86952026]
    #  [ 0.99786077  2.02202837  2.98579698]
    #  [ 7.01104783  5.88623677  8.07335002]]


    for k in range(len(palabras)):
        # print("####")
        vector = [s[0]*U[k][0],s[1]*U[k][1]]
        # print("vector: ",vector)
        flecha(vector[0], vector[1])
        punto(vector[0], vector[1], "o")
        texto(vector[0], vector[1], " - " + palabras[k])
        print(palabras[k],vector)


    '''A = np.array(matriz)
    print("Matriz A:")
    print(A)

    At = np.transpose(A)
    print("Matriz At:")
    print(At)
    B = np.dot(A,At)
    print("A· At")
    print(B)
    v , U = la.eig(C)
    autovalores , autovectores = la.eig(B)
    print(autovalores)
    print(autovectores)

    U = autovectores'''
'''
    C = np.dot(At,A)
    print("At· A")
    print(C)
    autovalores, autovectores = la.eig(C)
    print(autovalores)
    print(autovectores)
    V = autovectores


##    print("S:")
##    print(S)
##    print("U:")
##    print(U)
##    print("-----")
    sigma = np.sqrt(v)
    matrizAux = np.eye(2)
    for k in range(2):
        matrizAux[k][k] = sigma[k]
    sigmak2 = matrizAux
    #print(sigmak2)
    cont = 0
    for k in range(len(palabras)):
        Uk2Temp = U[k][0:2]
        #Chapuza
        Uk2Temp[1] = - Uk2Temp[1]
        #print(Uk2Temp)
        #print(sigmak2)
        #print("####")
        vector = np.dot(Uk2Temp,sigmak2)
        #print("vector: ",vector)
        flecha(vector[0],vector[1])
        punto(vector[0],vector[1],"o")
        texto(vector[0],vector[1]," - "+palabras[k])
        terminosOut.append(vectorLSA(vector[0],vector[1],palabras[k]))
    #print("Documentos:")
    #Documentos:
    for k in range(len(documentos)):
        Sk2Temp = S[k][0:2]
        #Chapuza
        Sk2Temp[0] = - Sk2Temp[0]
        #print(Sk2Temp)
        vector = np.dot(Sk2Temp,sigmak2)
        #print("vector: ",vector)
        flecha(vector[0],vector[1])
        punto(vector[0],vector[1],"x")
        texto(vector[0],vector[1]," - documento "+str(k+1))
        documentosOut.append(vectorLSA(vector[0],vector[1],str(k+1)))
    mostrarPlot()'''

if __name__=="main":
    matriz = [[1,1,0,0,0],[1,0,1,0,0],[0,0,0,1,1],[0,0,1,0,1],[0,0,0,0,1]]
    palabras = ["estudia","universidad","instituto","despacho",
                "trabaja"]
    '''matriz = [[1, 0, 1, 0, 0],
    [0 ,1 ,0 ,0, 0],
    [0 ,1 ,1 ,0, 0],
    [0 ,0 ,0 ,1, 0],
    [1 ,1 ,0 ,0, 0],
    [0 ,0 ,1 ,1, 0],
    [0 ,0 ,0 ,1, 0],
    [0 ,0 ,0 ,1 ,1]]'''
    singleValueDecomposition(matriz,palabras)
    mostrarPlot()