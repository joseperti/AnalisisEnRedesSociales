import math
from clasificadorLSA import *

def distanciaEuclidea(p1,p2):

    suma = 0
    for k in range(len(p1)):
        suma += (p1[k]-p2[k])**2
    distancia = math.sqrt(suma)
    return distancia

def puntosIguales(lista1,lista2):
    for k in range(min(len(lista1),len(lista2))):
        if lista1[k][0] != lista2[k][0]:
            return False
        elif lista1[k][1] != lista2[k][1]:
            return False
    return True

def masCercano(punto,lista):
    minimo = distanciaEuclidea(punto,lista[0])
    cercano = 0

    for k in range(len(lista)):
        if distanciaEuclidea(punto,lista[k])<minimo:
            cercano = k

    return cercano

def calcularPuntoMedio(lista):
    punto = []
    for k in lista[0]:
        punto.append(0)
    for k in range(lista):
        for i in lista[k]:
            punto[k] += i
    puntoFinal = []
    for k in punto:
        puntoFinal.append(k/len(lista))

    return puntoFinal


def algoritmoKMeans(puntos,K):
    ### Iniciamos creando los centroides aleatoriamente
    centroides = []
    for i in range(K):
        centroides.append(puntos[i])

    ### Calculamos los más cercanos
    clusters = []
    for i in centroides:
        clusters.append([])

    anteriores = [[0,0]]

    while not(puntosIguales(anteriores,centroides)):
        clusters = []
        for i in centroides:
            clusters.append([])
        for i in puntos:
            clusterObjetivo = masCercano(i,centroides)
            clusters[clusterObjetivo].append(i)
        anteriores = centroides
        centroides = []
        for i in range(len(centroides)):
            centroides.append(calcularPuntoMedio(clusters[i]))

    for i in puntos:
        punto(i[0],i[1],"o")
    for i in clusters:
        punto(i[0],i[1],"*")
        print(i)
    mostrarPlot()


algoritmoKMeans([[1,0],[1,1],[0,1],[-1,-1]],2)

