# -*- coding: utf-8 -*-
import numpy as np
from numpy import linalg as la
import matplotlib.pyplot as plt
import math
import copy
import re
import numpy as np
import nltk


class ClasificadorLSA():
    def __init__(self):
        None

    def divideTweetInWords(self, tweetIn):
        datos = [e.lower() for e in tweetIn.split() if len(e) >= 3]
        return datos

    def divideTweetInWordsSent(self, tweetsIn):
        tweets = []
        for k in tweetsIn:
            datos = datos = [e.lower() for e in k[0].split() if len(e) >= 3]
            tweets.append([datos, k[1]])
        return tweets

    def get_words_in_tweets(self, tweets):
        all_words = []
        for (words, sentiment) in tweets:
            all_words.extend(words)
        return all_words

    def get_word_features(self, wordlist):
        wordlist = nltk.FreqDist(wordlist)
        # print(wordlist)
        self.word_features = wordlist.keys()
        return self.word_features

    def extract_features(self, document):
        document_words = set(document)
        features = {}
        for word in self.word_features:
            features['contains(%s)' % word] = (word in document_words)
        return features

    def crearYEntrenar(self, tweetsIn):

        tweets = self.divideTweetInWordsSent(tweetsIn)
        # print(tweets)
        words_in_tweets = self.get_words_in_tweets(tweets)
        # print(words_in_tweets)
        self.word_features = self.get_word_features(words_in_tweets)
        #print(word_features)
        matriz = []
        for t in range(len(words_in_tweets)):
            matriz.append([])
            for w in self.word_features:
                matriz[t].append(words_in_tweets[t].count(w))
        documentos = ["D"+str(i) for i in range(len(tweetsIn))]
        sentimientos = [k[1] for k in tweetsIn]
        self.singleValueDecomposition(matriz, self.word_features, documentos,sentimientos)
        #print(matriz)


    def procesarDocumentoSolo(self, documento):
        return self.procesarDocumentoSentimiento(documento)

    def estudioAceptacion(self, tweetsIn):
        longitud = len(tweetsIn)
        num = 0
        aciertos = 0
        self.crearYEntrenar(tweetsIn)
        for k in range(longitud):
            aux = tweetsIn[0:k]
            aux += tweetsIn[k + 1:longitud]
            documento = tweetsIn[k]
            self.sentimiento = str(tweetsIn[k][1])
            # print("Documento:"+str(documento)+" sentimiento: "+str(documento[1]))
            clasificacion = self.procesarDocumentoSentimiento(tweetsIn[k][0])
            print("Esperado: "+self.sentimiento+" devuelto: "+clasificacion)
            if (self.sentimiento == str(clasificacion)):
                aciertos += 1
            num += 1

        return str(int(100 * (aciertos * 100) / num) / 100) + "%"

    def procesarDocumentoSentimiento(self,documento):
        palabras = list(self.extract_features(documento.split()))
        nuevoDocumento = []
        for w in self.word_features:
            nuevoDocumento.append(palabras.count(w))
        centro = [0, 0]
        for k in nuevoDocumento:
            centro[0] = centro[0] + self.vectoresPalabras[k][0]
            centro[1] = centro[1] + self.vectoresPalabras[k][1]
        centro[0] = centro[0] / len(nuevoDocumento)
        centro[1] = centro[1] / len(nuevoDocumento)
        print("La consulta obtenida es: ", centro)
        punto(centro[0], centro[1], "*")
        texto(centro[0], centro[1], "Consulta")
        minimo = 0
        documentosOpcion = dict()
        for k in range(len(self.sentimientos)):
            #print("Documento nuevo con Documento", k + 1, ":")
            #print("Centro: "+str(centro))
            #print("vector: "+str(self.vectoresDocumentos[k]))
            distancia = distanciaCoseno(centro, self.vectoresDocumentos[k])
            #print("Distancia: "+str(distancia))
            if distancia > minimo:
                documentosOpcion = dict()
                documentosOpcion[self.sentimientos[k]] = 1
            elif distancia == minimo:
                try:
                    documentosOpcion[self.sentimientos[k]] = documentosOpcion[self.sentimientos[k]]+1
                except:
                    documentosOpcion[self.sentimientos[k]] = 1
        return(self.obtenerSentimientoMaximo(documentosOpcion))

    def obtenerSentimientoMaximo(self,opciones):
        print(opciones)
        maximo = 0
        valor = None
        for k in opciones:
            if opciones[k] > maximo:
                valor = k
                maximo = opciones[k]
        return valor

    ###Procesamiento SVD de Matriz
    def singleValueDecomposition(self,matriz, palabras, documentos, sentimientos):
        self.sentimientos = sentimientos
        LA = np.linalg

        a = np.array(matriz)
        # print(a)
        # [[1 3 4]
        #  [5 6 9]
        #  [1 2 3]
        #  [7 6 8]]
        U, s, Vh = LA.svd(a, full_matrices=False)
        # assert np.allclose(a, np.dot(U, np.dot(np.diag(s), Vh)))
        #print("Autovalores:")
        #print(s)
        #print("..")
        s[2:] = 0
        new_a = np.dot(U, np.dot(np.diag(s), Vh))
        #print(U)
        #print(s)
        #print(Vh)
        #print(new_a)
        # [[ 1.02206755  2.77276308  4.14651336]
        #  [ 4.9803474   6.20236935  8.86952026]
        #  [ 0.99786077  2.02202837  2.98579698]
        #  [ 7.01104783  5.88623677  8.07335002]]
        self.vectoresPalabras = []

        for k in range(len(palabras)):
            # print("####")
            vector = [s[0] * U[k][0], s[1] * U[k][1]]
            # print("vector: ",vector)
            '''flecha(vector[0], vector[1])
            punto(vector[0], vector[1], "o")
            texto(vector[0], vector[1], " - " + palabras[k])
            print(palabras[k],vector)'''
            self.vectoresPalabras.append(vector)

            self.vectoresDocumentos = []
        for k in range(len(documentos)):
            # print("####")
            vector = [s[0] * Vh[0][k], s[1] * Vh[1][k]]
            # print("vector: ",vector)
            flecha(vector[0], vector[1])
            punto(vector[0], vector[1], "x")
            texto(vector[0], vector[1], " - " + documentos[k])
            #print(documentos[k], vector)
            self.vectoresDocumentos.append(vector)

def punto(x,y,symb):
    plt.plot(x,y,symb)

def texto(x,y,texto):
    plt.text(x,y,texto)

def flecha(dx,dy):
    plt.arrow(0,0,dx,dy)

def mostrarPlot():
    plt.ion()
    plt.xlim([-2,2])
    plt.ylim([-2,2])
    plt.show()

def modulo(d):
    return math.sqrt((d[0]**2) + (d[1]**2))

def distanciaCoseno(d1,d2):
    if d1[0]*d2[0]+d1[1]*d2[1] == 0:
        distancia = 0
    else:
        distancia = (d1[0]*d2[0]+d1[1]*d2[1])/(modulo(d1)*modulo(d2))
    #print("(<",d1,",",d2,">)/(",modulo(d1),"·",modulo(d2),") = ",distancia)
    return distancia



    
    

    '''A = np.array(matriz)
    print("Matriz A:")
    print(A)

    At = np.transpose(A)
    print("Matriz At:")
    print(At)
    B = np.dot(A,At)
    print("A· At")
    print(B)
    v , U = la.eig(C)
    autovalores , autovectores = la.eig(B)
    print(autovalores)
    print(autovectores)

    U = autovectores'''
'''
    C = np.dot(At,A)
    print("At· A")
    print(C)
    autovalores, autovectores = la.eig(C)
    print(autovalores)
    print(autovectores)
    V = autovectores


##    print("S:")
##    print(S)
##    print("U:")
##    print(U)
##    print("-----")
    sigma = np.sqrt(v)
    matrizAux = np.eye(2)
    for k in range(2):
        matrizAux[k][k] = sigma[k]
    sigmak2 = matrizAux
    #print(sigmak2)
    cont = 0
    for k in range(len(palabras)):
        Uk2Temp = U[k][0:2]
        #Chapuza
        Uk2Temp[1] = - Uk2Temp[1]
        #print(Uk2Temp)
        #print(sigmak2)
        #print("####")
        vector = np.dot(Uk2Temp,sigmak2)
        #print("vector: ",vector)
        flecha(vector[0],vector[1])
        punto(vector[0],vector[1],"o")
        texto(vector[0],vector[1]," - "+palabras[k])
        terminosOut.append(vectorLSA(vector[0],vector[1],palabras[k]))
    #print("Documentos:")
    #Documentos:
    for k in range(len(documentos)):
        Sk2Temp = S[k][0:2]
        #Chapuza
        Sk2Temp[0] = - Sk2Temp[0]
        #print(Sk2Temp)
        vector = np.dot(Sk2Temp,sigmak2)
        #print("vector: ",vector)
        flecha(vector[0],vector[1])
        punto(vector[0],vector[1],"x")
        texto(vector[0],vector[1]," - documento "+str(k+1))
        documentosOut.append(vectorLSA(vector[0],vector[1],str(k+1)))
    mostrarPlot()'''

if __name__=="main":
    matriz = [[1,0,0,0,0],[0,1,0,0,0],[0,0,1,0,0],[0,0,0,1,0],[0,0,0,0,1]]
    palabras = ["Favorito","Bonito","Mal","Feo",
                "Llegado"]
    documentos = ["D1","D2","D3","D4","D5"]
    '''matriz = [[1, 0, 1, 0, 0],
    [0 ,1 ,0 ,0, 0],
    [0 ,1 ,1 ,0, 0],
    [0 ,0 ,0 ,1, 0],
    [1 ,1 ,0 ,0, 0],
    [0 ,0 ,1 ,1, 0],
    [0 ,0 ,0 ,1, 0],
    [0 ,0 ,0 ,1 ,1]]'''
    sentimientos = []
    clasificador = ClasificadorLSA()
    clasificador.singleValueDecomposition(matriz,palabras,documentos,sentimientos)
    mostrarPlot()
