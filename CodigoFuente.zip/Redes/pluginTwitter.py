from Twitter.moduloCredenciales import *
import tweepy

class ventanaBusquedaNombreId(object):
    def __init__(self, master):
        top = self.top = Toplevel(master)
        top.minsize(320, 150)
        label = Label(top, text="Id de usuario: ")
        label.pack(fill=X)
        self.identificador = Entry(top)
        self.identificador.pack(fill=X)
        self.b = Button(top, text='Buscar', command=self.buscar, height=1, width=10)
        self.b.pack()
        self.info = Label(top, text="")
        self.info.pack()

    def buscar(self):
        self.info.config(text=obtenerNombreUsuarioId(self.identificador.get()))

api = None

def obtenerNombreUsuarioId(id):
    global api
    if api == None:
        credenciales = credencialesConexion()
        credenciales.cargarArchivo(credenciales.getRuta())
        consumerKey = credenciales.getConsumerKey()
        consumerSecret = credenciales.getConsumerSecret()
        accessToken = credenciales.getAccessToken()
        accessTokenSecret = credenciales.getAccessTokenSecret()

        auth = tweepy.OAuthHandler(consumerKey, consumerSecret)
        auth.secure = True
        auth.set_access_token(accessToken, accessTokenSecret)

        print("Creando api")
        api = tweepy.API(auth)
    results = api.get_user(id=id)
    return results.screen_name