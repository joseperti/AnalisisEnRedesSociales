# URL de guia: http://www.laurentluce.com/posts/twitter-sentiment-analysis-using-python-and-nltk/
#
#

import nltk

def divideTweetInWords(tweetIn):
    datos = [e.lower() for e in tweetIn.split() if len(e) >= 3]
    return datos

def divideTweetInWordsSent(tweetsIn):
    tweets = []
    for k in tweetsIn:
        datos = datos = [e.lower() for e in k[0].split() if len(e) >= 3]
        tweets.append([datos,k[1]])
    return tweets

def get_words_in_tweets(tweets):
    all_words = []
    for (words, sentiment) in tweets:
      all_words.extend(words)
    return all_words

def get_word_features(wordlist):
    wordlist = nltk.FreqDist(wordlist)
    print(wordlist)
    word_features = wordlist.keys()
    return word_features

def extract_features(document):
    document_words = set(document)
    features = {}
    for word in word_features:
        features['contains(%s)' % word] = (word in document_words)
    return features

def procesarDocumento(tweetsIn,documento):
    tweets = divideTweetInWordsSent(tweetsIn)
    #print(tweets)
    global word_features
    words_in_tweets = get_words_in_tweets(tweets)
    print(words_in_tweets)
    word_features = get_word_features(words_in_tweets)


    #Entrenamiento
    training_set = nltk.classify.apply_features(extract_features, tweets)

    #Entrenamos el clasificador
    classifier = nltk.NaiveBayesClassifier.train(training_set)

    tweet = documento
    features = extract_features(tweet.split())
    print(features)
    #print(classifier.show_most_informative_features(32))
    return classifier.classify(features)

def estudioAceptacion(tweetsIn):
    longitud = len(tweetsIn)
    num = 0
    aciertos = 0
    for k in range(longitud):
        aux = tweetsIn[0:k]
        aux += tweetsIn[k+1:longitud]
        documento = tweetsIn[k]
        clasificacion = procesarDocumento(aux,documento[0])
        print("Esperado: "+documento[1]+" devuelto: "+clasificacion)
        if (str(documento[1])==str(clasificacion)):
            aciertos += 1
        num += 1

    print("Porcentaje de aceptación: "+ str((aciertos*100)/num)+"%")


def clasificadorSimple(tweetsIn,documento):
    clasificacion = procesarDocumento(tweetsIn, documento)
    return clasificacion

######################################################################
# Ejecución principal
######################################################################
tweetsIn = [[
    '🔴 @Caro_Pascual92: "He llegado a coger comida del suelo para comer" https://t.co/hhLyWsuaWQ #AlgoMásQueDeporte https://t.co/W3QtSg3gnO\n',
    'negative'], [
    'Carolina Pascual, gimnasta "reconozco que he cogido algo del suelo o de una papelera para comer"  #AlgoMásQueDeporte\n',
    'negative'], [
    '"PASAS MAS HAMBRE QUE UN MAESTRO DE ESCUELA",POR: "PASAS MAS HAMBRE QUE UN DEPORTISTA DE ELITE" #AlgoMásQueDeporte\n',
    'negative'], [
    'RT @jordievole: Empezamos con @Caro_Pascual92 : “Fue duro. Con 12 años, sola, fuera de casa. Muchas noches llorando…” #AlgoMásQueDeporte\n',
    'negative'], [
    '@Caro_Pascual92: "Teníamos nuestros trucos para comer: comprar u potito para bebé o, incluso, algo que había en el suelo" #AlgoMásQueDeporte\n',
    'negative'],
    ['Lo dice... Cristina ... A modo de risa ... Y a mí me dan ganas de llorar #AlgoMásQueDeporte\n',
     'negative'], [
        'Pasarse la noche de domingo corriendo para quemar 3 botes de helado… También es la otra cara del deporte para C. Pascual #AlgoMásQueDeporte\n',
        'negative'], [
        '#AlgoMásQueDeporte joder a la madre de Carolina Pascual habria que acusarla de maltrato en 1er grado.\n',
        'negative'], ['Que duro 😓 #AlgoMasQueDeporte https://t.co/qMzkM7HzqD\n', 'negative'], [
        'RT @laSextaTV: 🔴 @Caro_Pascual92: "He llegado a coger comida del suelo para comer" https://t.co/hhLyWsuaWQ #AlgoMásQueDeporte https://t.co/…\n',
        'negative'], [
        'Entrenamientos de hasta 14 horas y una dieta que, a veces, no llegaba a las tres comidas diarias. Espeluznante #AlgoMásQueDeporte\n',
        'negative'],
    ['.@Caro_Pascual92 "Nunca había comido pan hasta que me retiré" #AlgoMásQueDeporte\n', 'negative'],
    ['#AlgoMásQueDeporte joder, y lo cuenta sonriendo! Esta gente está mal.\n', 'negative'], [
        'Error de todo deportista, y no deportista, para perder peso: NO CENAR #AlgoMásQueDeporte @salvadostv\n',
        'negative'], [
        'RT @jordievole: Empezamos con @Caro_Pascual92 : “Fue duro. Con 12 años, sola, fuera de casa. Muchas noches llorando…” #AlgoMásQueDeporte\n',
        'negative'], [
        'RT @laSextaTV: 🔴 @Caro_Pascual92: "He llegado a coger comida del suelo para comer" https://t.co/hhLyWsuaWQ #AlgoMásQueDeporte https://t.co/…\n',
        'negative'], [
        'RT @Toni_Rosa: No puede llover al gusto de tod@s y me hubiera gustado ver a Évole con Batistuta, pero dejo link #AlgoMásqueDeporte https://…\n',
        'negative'],
    ['#AlgoMásQueDeporte "si veía algo por el suelo o en la papelera, me lo llevaba a la boca"\n',
     'negative'], [
        'Q mártir esta gimnasta,  pero de los beneficios (económicos básicamente ) dice nada #AlgoMásQueDeporte\n',
        'negative'], [
        'RT @jordievole: Empezamos con @Caro_Pascual92 : “Fue duro. Con 12 años, sola, fuera de casa. Muchas noches llorando…” #AlgoMásQueDeporte\n',
        'negative'],
    ['Menudas triquiñuelas para la edad que tenían.. #AlgoMásQueDeporte\n', 'negative'], [
        'RT @laSextaTV: 🔴 @Caro_Pascual92: "He llegado a coger comida del suelo para comer" https://t.co/hhLyWsuaWQ #AlgoMásQueDeporte https://t.co/…\n',
        'negative'], [
        'RT @jordievole: Oiremos el relato descarnado de una atleta contando cómo y por qué se dopó. Pone los pelos de punta @3vir... #AlgoMásQueDep…\n',
        'negative'],
    ['Tremendo  lo que está contando de la comida.  https://t.co/kGlivkKTvJ\n', 'negative'], [
        'Nos encantaría que ya que pone el foco sobre el deporte, Salvados abordara la intolerable homofobia en el fútbol  #AlgoMásQueDeporte\n',
        'negative'], [
        'RT @silviagadu: Lo dice... Cristina ... A modo de risa ... Y a mí me dan ganas de llorar #AlgoMásQueDeporte\n',
        'negative'],
    ['RT @_anapastor_: Tremendo  lo que está contando de la comida.  https://t.co/kGlivkKTvJ\n',
     'negative'], ['Madre mía.. https://t.co/zp7YClwfOU\n', 'negative'],
    ['Cuando comentará lo bulimicas que se han quedado algunas. Triste. #AlgoMásQueDeporte\n',
     'negative'], [
        'RT @silviagadu: Lo dice... Cristina ... A modo de risa ... Y a mí me dan ganas de llorar #AlgoMásQueDeporte\n',
        'negative'],
    ['#AlgoMásQueDeporte espero que lo que estoy escuchando haya cambiado. Vergonzoso!!\n',
     'negative'], [
        'RT @pasamontesluis: #AlgoMásQueDeporte "si veía algo por el suelo o en la papelera, me lo llevaba a la boca"\n',
        'negative'], [
        'Carolina Pascual: "He cogido cosas del suelo o la papelera para llevármelas a la boca. Nunca comí pan hasta retirarme". #AlgoMásQueDeporte\n',
        'negative'],
    ['RT @_anapastor_: Tremendo  lo que está contando de la comida.  https://t.co/kGlivkKTvJ\n',
     'negative'], [
        'Mañana artículos de periodista pelmazos pensando que el deporte de élite son todo flores #AlgoMásQueDeporte\n',
        'negative'], [
        'RT @laSextaTV: 🔴 @Caro_Pascual92: "He llegado a coger comida del suelo para comer" https://t.co/hhLyWsuaWQ #AlgoMásQueDeporte https://t.co/…\n',
        'negative'],
    ['RT @_anapastor_: Tremendo  lo que está contando de la comida.  https://t.co/kGlivkKTvJ\n',
     'negative'], [
        '"había que hacer diez ejercicios perfectos de cada ejercicio. Hasta que no los hacía no me iba a casa" #AlgoMásQueDeporte\n',
        'negative'], [
        'RT @laSextaTV: 🔴 @Caro_Pascual92: "He llegado a coger comida del suelo para comer" https://t.co/hhLyWsuaWQ #AlgoMásQueDeporte https://t.co/…\n',
        'negative'], [
        'RT @laSextaTV: 🔴 @Caro_Pascual92: "He llegado a coger comida del suelo para comer" https://t.co/hhLyWsuaWQ #AlgoMásQueDeporte https://t.co/…\n',
        'negative'], [
        'Lo peor de grande deportistas como Carolina Pascual es que no son futbolistas de primera y no se les reconoce el esfuerzo #AlgoMásQueDeporte\n',
        'negative'], [
        'Me parece triste a la vez que admirable...bueno no lo se, estoy confundida #algomasquedeporte https://t.co/iEf4Os9aGk\n',
        'negative'], [
        'RT @salvadostv: Hablamos con @Caro_Pascual92 en el Estadi Olímpic de Barcelona. En los JJOO del 92 ganó una medalla. ¿A cambio de qué?  #Al…\n',
        'negative'],
    [
        'La otra cara del deporte de élite, la otra cara de los héroes de nuestra época #AlgoMásQueDeporte\n',
        'positive'],
    ['Que bonita se ve la rítmica desde fuera, ¿eh? #AlgoMásQueDeporte\n', 'positive'], [
        'RT @salvadostv: Empezamos viendo a los protagonistas de hoy, @JuanMata8 , @Caro_Pascual92 , y @3vir , triunfando... #AlgoMásQueDeporte\n',
        'positive'],
    ['Hoy no me pierdo Salvados! #AlgoMasQueDeporte  https://t.co/FkiQuyRTG9\n', 'positive'],
    ['RT @Santi_Millan: Hoy no me pierdo Salvados! #AlgoMasQueDeporte  https://t.co/FkiQuyRTG9\n',
     'positive'], ['Bruuuuuutal #AlgoMásQueDeporte\n', 'positive'],
    ['Interesante programa el de hoy @jordievole #AlgoMásQueDeporte\n', 'positive'], [
        'RT @pasamperh: Interesante @salvadostv esta noche, como siempre. Hoy la otra cara del deporte. https://t.co/yImYcDbQOA\n',
        'positive'], [
        'RT @jordievole: ATENCIÓN tuiteros de Salvados, el hashtag para comentar el programa de esta noche es #AlgoMásQueDeporte\n',
        'positive'], [
        'RT @laSextaTV: 🔴 Arranca @salvadostv. Síguelo en #directo a través de @AtresPlayer https://t.co/ctloFgC6dg #AlgoMásQueDeporte https://t.co/…\n',
        'positive'], [
        'RT @salvadostv: Empezamos viendo a los protagonistas de hoy, @JuanMata8 , @Caro_Pascual92 , y @3vir , triunfando... #AlgoMásQueDeporte\n',
        'positive'],
    ['.@Caro_Pascual92 a @jord: "Mi cuerpo era 90% de masa muscular" #AlgoMásQueDeporte\n',
     'positive'], [
        'RT @laSextaTV: 🔴 Arranca @salvadostv. Síguelo en #directo a través de @AtresPlayer https://t.co/ctloFgC6dg #AlgoMásQueDeporte https://t.co/…\n',
        'positive']]
estudioAceptacion()
#print(clasificadorSimple("cara"))

